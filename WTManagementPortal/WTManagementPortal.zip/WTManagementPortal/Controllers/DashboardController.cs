﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WTManagementPortal.ViewModels;

namespace WTManagementPortal.Controllers
{
    public class DashboardController : Controller
    {
        
        public ActionResult Main()
        {
            return View();
        }       
 
        public ActionResult _NoAgents()
        {
            List<DashboardGrid> allAgents = new List<DashboardGrid>();
            using (TestAgentDataEntities1 tada = new TestAgentDataEntities1())
            {
                var ag = tada.Agents.Where(a => a.Status != "TRUE");
                foreach (var i in ag)
                {
                    var aw = tada.Watches.Where(a => a.Agent_ID.Equals(i.Agent_ID)).ToList();
                    allAgents.Add(new DashboardGrid { agentList = i, agentDetails = aw });
                }
            }
            return PartialView(allAgents);
        }
    }    
}
